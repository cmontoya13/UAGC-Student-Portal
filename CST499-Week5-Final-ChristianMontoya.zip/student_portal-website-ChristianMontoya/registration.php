<?php
	error_reporting(E_ALL ^ E_NOTICE);

	session_start();

	$msg = false;


include 'db/db.php';
$sql = 'SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = "student_portal" AND TABLE_NAME = "tbluser"';
$result = $con->query($sql);
$nextID = $result -> num_rows;
$nextID = strval($nextID);
// $result -> free_result();

// add zeros preceeding short ids
if (strlen($nextID) == 1) {
	$nextID = 0 . 0 . $nextID;
} else if (strlen($id) == 2) {
	$nextID = 0 . $nextID;
}




	if(isset($_POST['submitBtn'])){ //check if form was submitted
		// Check if any empty values in required fields
		if (empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['password']) || empty($_POST['email'])) {
			die ('Please complete registration');
		}
		// Check if all values were entered
		else if (!isset($_POST['firstName'], $_POST['lastName'], $_POST['password'], $_POST['email'])) {
			die ('Please complete registration');
		}
		// Open database connection
		else {
			
			// include 'db/db.php';

			// Create student ID
			$studentID = strtoupper(substr($_POST['firstName'], 0,2) . substr($_POST['lastName'], 0,3)) . $nextID;

			// Begin 'Prepared Statement' to check if user exists
			if ($stmt = $con->prepare('SELECT id FROM tbluser WHERE firstName = ? AND lastName = ?')) {
				$stmt->bind_param('ss', $_POST['firstName'], $_POST['lastName']);
				$stmt->execute();
				$stmt->store_result();

				// Check if username already exists
				if ($stmt->num_rows > 0) {
					$msg = true;
				} else {
					// Begin 'Prepared Statement' to register user
					if ($stmt = $con->prepare('INSERT INTO tbluser (studentID, firstName, lastName, password, email, phone) VALUES (?, ?, ?, ?, ?, ?)')) {
						$passEncrypt = password_hash($_POST['password'], PASSWORD_DEFAULT);
						$stmt->bind_param('ssssss', $studentID ,$_POST['firstName'], $_POST['lastName'], $passEncrypt, $_POST['email'], $_POST['phone']);
						$stmt->execute();
						$_SESSION["registered"] = true;
						$_SESSION["studentID"] = $studentID;					
						header('location: login.php');
					}
				$stmt->close();	
				}
			$con->close();	
			}			
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title> Registration Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">

		<h2>Welcome to the Registration Page</h2>

		<?php
			if ($msg == true) {
				echo "User already exists - try logging in.";
			}
		?>

		<form method="post" style="margin-top: 40px; width: 500px">
			<div class="form-group">
				<label for="firstName" style="margin-bottom: 5px;">First Name</label>
				<input type="text" class="form-control" id="firstName" name="firstName" pattern="[A-Za-z]{1,30}" title="First Name - letters only" required>
			</div>
			<div class="form-group">
				<label for="lastName" style="margin-bottom: 5px;">Last Name</label>
				<input type="text" class="form-control" id="lastName" name="lastName" pattern="[A-Za-z]{1,30}" title="Last Name - letters only" required>
			</div>
			<div class="form-group">
				<label for="password" style="margin-bottom: 5px;">Password</label>
				<input type="password" class="form-control" id="password" name="password" pattern="(?=.*\d)(?=.*\w).{6,}" title="Must contain a number, letter and be 6 digits long" required>
			</div>
			<div class="form-group">
				<label for="email" style="margin-bottom: 5px;">Email address</label>
				<input type="email" class="form-control" id="email"  name="email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}$" title="Email format is incorrect or missing dot" required>
			</div>
			<div class="form-group">
				<label for="phone" style="margin-bottom: 5px;">Phone Number</label>
				<input type="tel" class="form-control" id="phone" name="phone" minlength="10" maxlength="10" pattern="[0-9]{10}" title="Area code and phone number (10 numbers - no symbols)">
			</div>
			<button type="submit" class="btn btn-primary" name="submitBtn">Submit</button>
		</form>
	</div>

	<?php require_once 'footer.php';?>

</body>
</html>

