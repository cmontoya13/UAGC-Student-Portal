

CREATE DATABASE if not exists student_portal;

USE student_portal;

CREATE TABLE tbluser (
	id int(11) AUTO_INCREMENT NOT NULL,
	studentID varchar(10) NOT NULL,
	firstName varchar(30) NOT NULL,
	lastName varchar(30) NOT NULL,
	password varchar(255) NOT NULL,
	email varchar(50) NOT NULL,
	phone varchar(10),
	spring_enrolled varchar(255),
	spring_waiting varchar(255),
	winter_enrolled varchar(255),
	winter_waiting varchar(255),
	fall_enrolled varchar(255),
	fall_waiting varchar(255),
	PRIMARY KEY (id)
);

SELECT * FROM student_portal.tbluser;

USE student_portal;
INSERT INTO tbluser (studentID, firstName, lastName, password, email, phone, spring_enrolled, spring_waiting)
VALUES("DAVAD001", "Darth", "Vader", "abc123", "vader@sithlord.com", "8179374091", "SCI321", "ENG210");

INSERT INTO tbluser (studentID, firstName, lastName, password, email, phone, spring_enrolled, spring_waiting)
VALUES("HASOL001", "Han", "Solo", "abc123", "solo@millenium-falcon.com", "9283794129", "SCI321", "ENG210");

-- ADD A COLUMN AFTER/BEFORE ANOTHER
ALTER TABLE tbluser
ADD <new category> int(2)
AFTER email; -- DROP THIS TO ADD TO END

-- ADD VALUES TO ALL ROWS OF NEW COLUMN
INSERT INTO tbluser (id, password)
VALUES(6, "abc123"),(12, "abc123");

-- DELETE A COLUMN
ALTER TABLE tbluser
DROP email, DROP phone;

-- DELETE USER/ROW
DELETE FROM tbluser
WHERE lastName = "Vader";

-- CHANGE USER DATA
UPDATE tbluser
SET firstName = "Luke", lastName = "Skywalker"
WHERE id = 2;

-- CHANGE A FIELD
UPDATE tbluser
SET phone = "9283794129"
WHERE id = 5;

-- DELETE A FIELD
UPDATE tbluser
SET email = NULL
WHERE id = 3

-- CHANGE COLUMN DATA
ALTER TABLE fall_courses
CHANGE id courseID varchar(10) NOT NULL;

-- DELETE TABLE
DROP TABLE student_portal.tbluser;

-- DELETE ALL DATA WITHIN A TABLE
TRUNCATE TABLE student_portal.tbluser;

-- CHANGE COLUMN SETTINGS
ALTER TABLE tbluser
MODIFY COLUMN password varchar(255);


--------------------------------------------------------------------


USE student_portal;

CREATE TABLE spring_courses (
	courseID varchar(10) NOT NULL,
	courseName varchar(50) NOT NULL,
	instructor varchar(30) NOT NULL,
	capacity tinyint(4) NOT NULL,
	enrolled tinyint(4),
	waiting tinyint(4),
	PRIMARY KEY (id)
);

CREATE TABLE fall_courses (
	courseID varchar(10) NOT NULL,
	courseName varchar(50) NOT NULL,
	instructor varchar(30) NOT NULL,
	capacity tinyint(4) NOT NULL,
	enrolled tinyint(4),
	waiting tinyint(4),
	PRIMARY KEY (id)
);

CREATE TABLE winter_courses (
	courseID varchar(10) NOT NULL,
	courseName varchar(50) NOT NULL,
	instructor varchar(30) NOT NULL,
	capacity tinyint(4) NOT NULL,
	enrolled tinyint(4),
	waiting tinyint(4),
	PRIMARY KEY (id)
);

ENG210, SCI321, MAT122, ART420, ECO101

-- ADD VALUES TO ALL ROWS OF NEW COLUMN
INSERT INTO spring_courses (courseID, courseName, instructor, capacity, enrolled, waiting)
VALUES("ENG210", "English Composition", "Fitzgerald", 20, 18),("SCI321", "Physical Science", "Goodwyn", 20, 15),("MAT122", "Calculus", "Smith", 15, 12),("ART420", "Oil Painting", "Zevedra", 20, 17),("ECO101", "Economics", "Bhakta", 30, 28);

INSERT INTO fall_courses (courseID, courseName, instructor, capacity, enrolled, waiting)
VALUES("ENG210", "English Composition", "Fitzgerald", 20, 5),("SCI321", "Physical Science", "Goodwyn", 20, 2),("MAT122", "Calculus", "Smith", 15, 3),("ART420", "Oil Painting", "Zevedra", 20, 5),("ECO101", "Economics", "Bhakta", 30, 0);

INSERT INTO winter_courses (courseID, courseName, instructor, capacity, enrolled, waiting)
VALUES("ENG210", "English Composition", "Fitzgerald", 20, 0),("SCI321", "Physical Science", "Goodwyn", 20, 0),("MAT122", "Calculus", "Smith", 15, 0),("ART420", "Oil Painting", "Zevedra", 20, 0),("ECO101", "Economics", "Bhakta", 30, 0);


--------------------------------------------------------------------




