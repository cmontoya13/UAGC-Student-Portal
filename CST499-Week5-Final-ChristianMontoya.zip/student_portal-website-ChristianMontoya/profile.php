<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();

	$msg = false;

	// Check if the user is logged in, if not then redirect to home page
	if (!isset($_SESSION['id']) || $_SESSION['id'] != true) {
	    header('location: index.php');
	}
	else {

		include 'db/db.php';

		// Begin 'Prepared Statement' to confirm user
		if ($stmt = $con->prepare('SELECT * FROM tbluser WHERE id = ?')) {
			$stmt->bind_param('i', $_SESSION['id']);
			$stmt->execute();
			$result = $stmt->get_result();
			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();
				$studentID = $row["studentID"];
				$firstName = $row["firstName"];
				$lastName = $row["lastName"];						
				$password = $row["password"];
				$email = $row["email"];
				$phone = $row["phone"];
				$id = $row["id"];

				// shorten encrypted pw - password
				$password = substr($password, 0, 15) . "... Encrypted";

				// convert to standard format - phone
				$phone1 = substr($phone, 0,3);
				$phone2 = substr($phone, 3,3);
				$phone3 = substr($phone, 6,4);
				$phone = "(" . $phone1 . ") " . $phone2 . "-" . $phone3;

			} else { // no results
				$msg = true;
			}
			$stmt->close(); 
		}
		$con->close();
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title> Profile Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">
		<h2>Welcome to the Profile Page</h2>

		<?php
			if ($msg == true) {
				echo "You need to be logged in to view your profile";
			}
		?>

		<ul class="list-group" style="margin-top: 40px; width: 400px">
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 80px">Student ID</span>
				<?php echo $studentID;?>
			</li>
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 60px;">First</span>
				<?php echo $firstName;?>
			</li>
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 60px">Last</span>
				<?php echo $lastName;?>
			</li>
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 60px">Pass</span>
				<?php echo $password;?>
			</li>
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 60px">Email</span>
				<?php echo $email;?>
			</li>
			<li class="list-group-item d-flex justify-content-between align-items-left">
				<span class="badge badge-primary badge-pill" style="background-color: #DD6E0F; padding: 5px 8px; width: 60px">Phone</span>
				<?php echo $phone;?>
			</li>
		</ul>
	</div>

	<?php require_once 'footer.php';?>

</body>
</html>

