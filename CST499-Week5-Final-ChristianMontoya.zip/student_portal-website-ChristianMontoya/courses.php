<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();

	$msg = false;

	// Check if the user is logged in, if not then redirect to home page
	if (!isset($_SESSION['id']) || $_SESSION['id'] != true) {
	    header('location: index.php');
	}
	else {

		include 'db/db.php';

		// GET COURSES DATA
		$spring_sql = "SELECT * FROM spring_courses";
		$spring_result = mysqli_query($con, $spring_sql);

		$winter_sql = "SELECT * FROM winter_courses";
		$winter_result = mysqli_query($con, $winter_sql);

		$fall_sql = "SELECT * FROM fall_courses";
		$fall_result = mysqli_query($con, $fall_sql);

		// GET STUDENT DATA
		if ($stmt = $con->prepare('SELECT * FROM tbluser WHERE id = ?')) {
			$stmt->bind_param('i', $_SESSION['id']);
			$stmt->execute();
			$result = $stmt->get_result();
			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();
				$spring_enrolled = $row["spring_enrolled"];
				$spring_waiting = $row["spring_waiting"];
				$winter_enrolled = $row["winter_enrolled"];
				$winter_waiting = $row["winter_waiting"];
				$fall_enrolled = $row["fall_enrolled"];
				$fall_waiting = $row["fall_waiting"];
			} else { // no results
				$msg = true;
			}
			$stmt->close(); 
		}
		$con->close();
	}

	// ON SUBMITS
	// ADD COURSE
	if (isset($_POST['addBtn'])) { //check if form was submitted

		// Check if any empty values in required fields
		if (empty($_POST['semester']) || empty($_POST['code'])) {
			die ('Please complete all fields');
		}
		// Check if all values were entered
		else if (!isset($_POST['semester'], $_POST['code'])) {
			die ('Please complete all fields');
		}
		else {

			include 'db/db.php';

			// SUBMITTED DATA
			$semester = $_POST['semester'];
			$code = $_POST['code'];			

			if ($stmt = $con->prepare('SELECT capacity, enrolled, waiting FROM '.$semester.'_courses WHERE courseID = ?')) {
				$stmt->bind_param('s', $code);
				$stmt->execute();
				$result = $stmt->get_result();
				if ($result->num_rows > 0) {
					$row = $result->fetch_assoc();				
					if ($row["capacity"] > $row["enrolled"]) {
						// increment 'enrolled' by 1
						if ($stmt = $con->prepare('UPDATE '.$semester.'_courses SET enrolled = ? WHERE courseID = ?')) {
							$enroll = $row["enrolled"] + 1;
							$stmt->bind_param('is', $enroll, $code);
							$stmt->execute();
						}
						// add course to tbluser
						if ($stmt = $con->prepare('UPDATE tbluser SET '.$semester.'_enrolled = ? WHERE id = ?')) {
							$thisSemester = $semester."_enrolled";
							$student_courses = $$thisSemester . "<br>" . $code;
							$stmt->bind_param('si', $student_courses, $_SESSION['id']);
							$stmt->execute();						
						}					
						header('location: courses.php');
					} else {
						// increment 'waiting' by 1
						if ($stmt = $con->prepare('UPDATE '.$semester.'_courses SET waiting = ? WHERE courseID = ?')) {
							$wait = $row["waiting"] + 1;
							$stmt->bind_param('is', $wait, $code);
							$stmt->execute();
						}
						// add waiting course to tbluser
						if ($stmt = $con->prepare('UPDATE tbluser SET '.$semester.'_waiting = ? WHERE id = ?')) {
							$thisSemester = $semester."_waiting";
							$student_courses = $$thisSemester . "<br>" . $code;
							$stmt->bind_param('si', $student_courses, $_SESSION['id']);
							$stmt->execute();						
						}
						header('location: courses.php');
					}
				}
				$stmt->close();
			}
			$con->close();
		}
	}

	// WITHDRAW COURSE
	if (isset($_POST['withBtn'])) { //check if form was submitted

		// Check if any empty values in required fields
		if (empty($_POST['semester']) || empty($_POST['code'])) {
			die ('Please complete all fields');
		}
		// Check if all values were entered
		else if (!isset($_POST['semester'], $_POST['code'])) {
			die ('Please complete all fields');
		}
		else {

			include 'db/db.php';

			// SUBMITTED DATA
			$semester = $_POST['semester'];
			$code = $_POST['code'];			

			if ($stmt = $con->prepare('SELECT capacity, enrolled FROM '.$semester.'_courses WHERE courseID = ?')) {
				$stmt->bind_param('s', $code);
				$stmt->execute();
				$result = $stmt->get_result();
				if ($result->num_rows > 0) {
					$row = $result->fetch_assoc();
					// decrement 'enrolled' by 1
					if ($stmt = $con->prepare('UPDATE '.$semester.'_courses SET enrolled = ? WHERE courseID = ?')) {
						$enroll = $row["enrolled"] - 1;
						$stmt->bind_param('is', $enroll, $code);
						$stmt->execute();
					}
					// remove course from tbluser
					if ($stmt = $con->prepare('UPDATE tbluser SET '.$semester.'_enrolled = ? WHERE id = ?')) {
						$thisSemester = $semester."_enrolled";
						$withdrew = str_replace("<br>" . $code, "",$$thisSemester);
						$stmt->bind_param('si', $withdrew, $_SESSION['id']);
						$stmt->execute();						
					}					
					header('location: courses.php');
				}
				$stmt->close();
			}
			$con->close();
		}
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title> Courses Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">
		<h2>Welcome to the Courses Page</h2>

		<h3 style='margin-top:20px;font-weight:bold'>Available Courses</h3>

		<?php
			if ($msg == true) {
				echo "You need to be logged in to view course data";
			}
		?>


		<?php
			// SPRING SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;'>";
			echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:#DD6E0F;color:#fff'>Spring Semester</caption>";
			echo "<tr>";
			echo "<th style='padding:5px;font-weight:bold'>Code</th>";
			echo "<th style='padding:5px;font-weight:bold'>Course</th>";
			echo "<th style='padding:5px;font-weight:bold'>Instructor</th>";
			echo "<th style='padding:5px;font-weight:bold'>Capacity</th>";
			echo "<th style='padding:5px;font-weight:bold'>Students</th>";
			echo "<th style='padding:5px;font-weight:bold'>Waiting</th>";
			echo "</tr>";
			while ($spring_row = mysqli_fetch_assoc($spring_result)) {
			    echo "<tr>";
			    foreach($spring_row as $spring_value) {
			        echo "<td style='padding:5px'>" . $spring_value . "</td>";
			    }
			    echo "</tr>";
			}
			echo "</table>";
		?>

		<?php
			// WINTER SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;'>";
			echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:#DD6E0F;color:#fff'>Winter Semester</caption>";
			echo "<tr>";
			echo "<th style='padding:5px;font-weight:bold'>Code</th>";
			echo "<th style='padding:5px;font-weight:bold'>Course</th>";
			echo "<th style='padding:5px;font-weight:bold'>Instructor</th>";
			echo "<th style='padding:5px;font-weight:bold'>Capacity</th>";
			echo "<th style='padding:5px;font-weight:bold'>Students</th>";
			echo "<th style='padding:5px;font-weight:bold'>Waiting</th>";
			echo "</tr>";
			while ($winter_row = mysqli_fetch_assoc($winter_result)) {
			    echo "<tr>";
			    foreach($winter_row as $winter_value) {
			        echo "<td style='padding:5px'>" . $winter_value . "</td>";
			    }
			    echo "</tr>";
			}
			echo "</table>";
		?>

		<?php
			// FALL SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;'>";
			echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:#DD6E0F;color:#fff''>Fall Semester</caption>";
			echo "<tr>";
			echo "<th style='padding:5px;font-weight:bold'>Code</th>";
			echo "<th style='padding:5px;font-weight:bold'>Course</th>";
			echo "<th style='padding:5px;font-weight:bold'>Instructor</th>";
			echo "<th style='padding:5px;font-weight:bold'>Capacity</th>";
			echo "<th style='padding:5px;font-weight:bold'>Students</th>";
			echo "<th style='padding:5px;font-weight:bold'>Waiting</th>";
			echo "</tr>";
			while ($fall_row = mysqli_fetch_assoc($fall_result)) {
			    echo "<tr>";
			    foreach($fall_row as $fall_value) {
			        echo "<td style='padding:5px'>" . $fall_value . "</td>"; 
			    }
			    echo "</tr>";
			}
			echo "</table>";
		?>

		<!-- ************************************************************************* -->

		<h3 style='margin-top:20px;font-weight:bold'>Your Courses</h3>

		<?php
			// SPRING SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;width:500px'>";
				echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:SaddleBrown;color:#fff'>Spring Semester</caption>";
				echo "<tr style='width:240px'>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Enrolled</th>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Waiting List</th>";
				echo "</tr>";
				echo "<tr style='width:240px'>";
					echo "<td style='padding:5px'>" . $spring_enrolled . "</td>";
					echo "<td style='padding:5px'>" . $spring_waiting . "</td>";
				echo "<tr>";
			echo "</table>";
		?>

		<br>

		<?php
			// WINTER SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;width:500px'>";
				echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:SaddleBrown;color:#fff'>Winter Semester</caption>";
				echo "<tr style='width:240px'>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Enrolled</th>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Waiting List</th>";
				echo "</tr>";
				echo "<tr style='width:240px'>";
					echo "<td style='padding:5px'>" . $winter_enrolled . "</td>";
					echo "<td style='padding:5px'>" . $winter_waiting . "</td>";
				echo "<tr>";
			echo "</table>";
		?>

		<br>

		<?php
			// FALL SEMESTER
			echo "<table style='display:inline-block;margin: 20px 0 0 20px;padding:10px;border:solid 1px grey;width:500px'>";
				echo "<caption style='margin-bottom:5px;padding:8px;font-weight:bold;background-color:SaddleBrown;color:#fff'>Fall Semester</caption>";
				echo "<tr style='width:240px'>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Enrolled</th>";
				echo "<th style='padding:5px;font-weight:bold;width:240px'>Waiting List</th>";
				echo "</tr>";
				echo "<tr style='width:240px'>";
					echo "<td style='padding:5px'>" . $fall_enrolled . "</td>";
					echo "<td style='padding:5px'>" . $fall_waiting . "</td>";
				echo "<tr>";
			echo "</table>";
		?>

		<!-- ************************************************************************* -->

		<h3 style='margin-top:20px;font-weight:bold'>Add/Withdraw Courses</h3>
			<form method="post" style="margin: 20px 0 0 20px;width:600px">
			<div class="form-group" style='display:inline-block'>
				<label for="semester" style="margin-bottom: 5px;">Semester</label>
				<select type="text" class="form-control" id="semester"  name="semester" title="Select the semester" required>
					<option value="spring">Spring</option>
					<option value="winter">Winter</option>
					<option value="fall">Fall</option>
				</select>
			</div>
			<div class="form-group" style='display:inline-block'>
				<label for="code" style="margin-bottom: 5px;">Course Code</label>
				<input type="text" class="form-control" id="code" name="code" maxlength="10" title="Enter the course code" required>
			</div>
			<button type="submit" class="btn btn-primary" style='display:inline-block' name="addBtn">ADD</button>
			<button type="submit" class="btn btn-primary" style='display:inline-block' name="withBtn">WITHDRAW</button>

		</form>

	</div>

	<?php require_once 'footer.php';?>

</body>
</html>