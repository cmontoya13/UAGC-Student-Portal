<?php
	error_reporting(E_ALL ^ E_NOTICE);
	// $errorLogLocation = ini_get('error_log');
	// echo 'Your error log is located at: ' . $errorLogLocation;
	session_start();

	// Check for Logout parameter in url
	if (isset($_GET['Logout'])) {
		if ($_GET['Logout'] == 1) {
			session_unset();
			session_destroy();
		}
	}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title> Home Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">
		<h2>Welcome to the Home Page</h2>

		<?php			
			if (isset($_SESSION['username'])) {
				echo $_SESSION['username'];
			}
		?>
		
	</div>

	<?php require_once 'footer.php';?>

</body>
</html>

