<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();

	$msg = false;

	if (isset($_POST['submitBtn'])) { //check if form was submitted
		// Check if any empty values in required fields
		if (empty($_POST['password']) || empty($_POST['studentID'])) {
			die ('Please complete login');
		}
		// Check if all values were entered
		else if (!isset($_POST['password'], $_POST['studentID'])) {
			die ('Please complete registration');
		}
		// Open database connection
		else {
			
			include 'db/db.php';

			// Begin 'Prepared Statement' to confirm user
			if ($stmt = $con->prepare('SELECT id, firstName, lastName, password FROM tbluser WHERE studentID = ?')) {
				$stmt->bind_param('s', $_POST['studentID']);
				$stmt->execute();
				$result = $stmt->get_result();
				if ($result->num_rows > 0) {
					$row = $result->fetch_assoc();					
					// Check entered password against encrypted password
					if (password_verify($_POST['password'], $row['password'])) {
						$id = $row["id"];
						$userName = $row["firstName"] . " " . $row["lastName"];
						$_SESSION["id"] = $id;
						$_SESSION["username"] = $userName;							
						header('location: index.php');
					} else {
						$msg = true; // password incorrect
					}
				} else {
					$msg = true; // no matching results
				}
				$stmt->close(); 
			}
			$con->close();
		}
	}
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title> Login Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">

		<h2>Welcome to the Login Page</h2>

		<?php
			if ($msg == true) {
				echo "Login Failed - please try again";
			}
			if (isset($_SESSION["registered"])) {
				echo "Registration Success - Please log in. <br>
				Please take note that your student ID is: " . $_SESSION["studentID"];
				unset($_SESSION["registered"]);
				unset($_SESSION["studentID"]);
			}
		?>

		<form method="post" style="margin-top: 40px; width: 500px">
			<div class="form-group">
				<label for="studentID" style="margin-bottom: 5px;">Student ID</label>
				<input type="studentID" class="form-control" id="studentID"  name="studentID" title="Student ID format is incorrect" required>
			</div>
			<div class="form-group">
				<label for="password" style="margin-bottom: 5px;">Password</label>
				<input type="password" class="form-control" id="password" name="password" pattern="(?=.*\d)(?=.*\w).{6,}" title="Must contain a number, letter and be 6 digits long" required>
			</div>
			<button type="submit" class="btn btn-primary" name="submitBtn">Submit</button>
		</form>
	</div>

	<?php require_once 'footer.php';?>

</body>
</html>

