<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();

	$msg = false;

	// Check if the user is logged in, if not then redirect him to login page
	if (!isset($_SESSION['id']) || $_SESSION['id'] != true) {
	    header('location: index.php');
	}
	else {
		if (isset($_POST['submitBtn'])) { //check if form was submitted
			// Check if any empty values in required fields
			if (empty($_POST['password']) || empty($_POST['email'])) {
				die ('Please complete all fields');
			}
			// Check if all values were entered
			else if (!isset($_POST['password'], $_POST['email'])) {
				die ('Please complete all fields');
			}
			// Open database connection
			else {
				
				include 'db/db.php';

				// Begin 'Prepared Statement' to confirm user
				if ($stmt = $con->prepare('SELECT password FROM tbluser WHERE email = ?')) {
					$stmt->bind_param('s', $_POST['email']);
					$stmt->execute();
					$result = $stmt->get_result();
					if ($result->num_rows > 0) {
						$row = $result->fetch_assoc();					
						// Check entered password against encrypted password
						if (password_verify($_POST['password'], $row['password'])) {
							if ($stmt = $con->prepare('DELETE FROM tbluser WHERE email = ?')) {
								$stmt->bind_param('s', $_POST['email']);
								$stmt->execute();							
								header('location: index.php?Logout=1');
							}
						} else {
							$msg = true; // password incorrect
						}
					} else {
						$msg = true; // no matching results
					}
					$stmt->close(); 
				}
				$con->close();
			}
		}
	}
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title> Unsubscribe Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device=width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.css"></script>
</head>
<body>
	
	<?php require_once 'master.php';?>

	<div class="container text-left">

		<h2>Please Confirm to Unsubscribe</h2>

		<?php
			if ($msg == true) {
				echo "Unsubscribe Failed - please try again";
			}
		?>

		<form method="post" style="margin-top: 40px; width: 500px">
			<div class="form-group">
				<label for="password" style="margin-bottom: 5px;">Password</label>
				<input type="password" class="form-control" id="password" name="password" pattern="(?=.*\d)(?=.*\w).{6,}" title="Must contain a number, letter and be 6 digits long" required>
			</div>
			<div class="form-group">
				<label for="email" style="margin-bottom: 5px;">Email address</label>
				<input type="email" class="form-control" id="email"  name="email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,}$" title="Email format is incorrect or missing dot" required>
			</div>
			<button type="submit" class="btn btn-primary" name="submitBtn">Submit</button>
		</form>
	</div>

	<?php require_once 'footer.php';?>

</body>
</html>

